
Launcher is a platform where CS and engineering students post their projects and meet potential team members. 
